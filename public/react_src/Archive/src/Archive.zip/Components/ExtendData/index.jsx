import React from 'react';
import axios from 'axios';
import {Input, Button, Icon, Row, Toast} from 'react-materialize';
import Geocode from "react-geocode";
import MyCarousel from '../MyCarousel/';

class ExtendData extends React.Component{

	constructor(props) {
		super(props);

		this.state = {
			FirstName: '',
			LastName: '',
			City: '',
			Country: '',
			Adress: '',
			Preferences: '',
			Age: '',
			Bio: '',
			Lat: '',
			Lng: '',
			Gender: 'Male',
			Sexpref: 'Heterosexual',
			Pics: [],
			PicsURL: []
		}
		this.prepareForm = this.prepareForm.bind(this);
		this.submitForm = this.submitForm.bind(this);
		this.choseGender = this.choseGender.bind(this);
		this.chosePrefer = this.chosePrefer.bind(this);
		this.changeAge = this.changeAge.bind(this);
		this.changeName = this.changeName.bind(this);
		this.changeLastName = this.changeLastName.bind(this);
		this.changeCity = this.changeCity.bind(this);
		this.changeCountry = this.changeCountry.bind(this);
		this.changeAdress = this.changeAdress.bind(this);
		this.changePreferences = this.changePreferences.bind(this);
	}

	submitForm(data) {
		 axios({
            url: 'http://e1r2p10:8800/',

            method: 'post', 

            headers: {
                'Content-Type': 'multipart/form-data',
            },

            data: data,

            responseType: 'json'
        })
        .then(response => {
            if (response.data) {
                this.Auth.setToken(response.data.token);
                this.props.history.replace('/');
            }
        })
        .catch(errors => {
            console.log(errors);
        });
	}

	prepareForm() {
        let data = new FormData();
        data.append('FirstName', this.state.FirstName);
        data.append('LastName', this.state.LastName);
        data.append('City', this.state.City);
        data.append('Country', this.state.Country);
        data.append('Age', this.state.Age);
        data.append('Gender', this.state.Gender);
        data.append('Sexpref', this.state.Sexpref);
        data.append('Pics', this.state.Pics);

//         if (this.state.City !== '' || this.state.Country !== '' || this.state.Adress !== ''){
// console.log("dddd");
//         } else {
        	Geocode.setApiKey("AIzaSyAZui479HQ-RvwHw2DgzKj585znt0i5iL4");
        	Geocode.fromAddress("Eiffel Tower")
        	.then(response => {
        		console.log(response.results[0].geometry);
        	});

        // }
  		
        // console.log(this.state.FirstName);
        // console.log(this.state.LastName);
        // console.log(this.state.City);
        // console.log(this.state.Country);
        // console.log(this.state.Adress);
        // console.log(this.state.Age);
        // console.log(this.state.Gender);
        // console.log(this.state.Sexpref);
        // console.log(this.state.Pics);
    }

    // async getGeocode(tmp) {
    // 	Geocode.setApiKey("AIzaSyAZui479HQ-RvwHw2DgzKj585znt0i5iL4");
    // 	return await Geocode.fromAddress(tmp);
    // }

    choseGender(event) {
    	this.setState ({
    		Gender: event.target.value
    	});
    	console.log(this.state.Gender);
    }

   chosePrefer(event) {
    	this.setState ({
    		Sexpref: event.target.value
    	});
    	console.log(this.state.Sexpref);
    }

    changeAge(event) {
    	let isnum = /^\d+$/.test(event.target.value);

    	if (isnum || event.target.value === '') {
    		this.setState ({
    			Age: event.target.value
    		});

   	 	} else {
   	 		window.Materialize.toast('I am a toast!', 2000, 'blue rounded');

   	 	}
    }

    changeName(event) {
    	this.setState ({
    		FirstName: event.target.value
    	});
    }

    changeLastName(event) {
    	this.setState ({
    		LastName: event.target.value
    	});
    }

    changeCity(event) {
    	this.setState ({
    		City: event.target.value
    	});
    }

    changeCountry(event) {
    	this.setState ({
    		Country: event.target.value
    	});
    }

    changeAdress(event) {
    	this.setState ({
    		Adress: event.target.value
    	});
    }

    changePreferences(event) {
    	this.setState ({
    		Preferences: event.target.value
    	});
    }

    fileHendler = event => {
    	let tmp = this.state.Pics;
    	let tempURL = this.state.PicsURL;

    	if (tmp.length < 5) {
    		tmp.push(event.target.files[0]);
    		tempURL.push(URL.createObjectURL(event.target.files[0]));
    	} else {
    		for (let i = 1; i < tmp.length; i++) {
    			tmp[i - 1] = tmp[i];
    			tempURL[i - 1] = tempURL[i];
    		}
    		tmp[4] = event.target.files[0];
    		tempURL[4] = URL.createObjectURL(event.target.files[0]);
    	}
    	this.setState ({
    		Pics: tmp,
    		PicsURL: tempURL
    	});
    }


    picDisplay = () => {
    	if (this.state.Pics.length === 0) {
    		return (
    			<Row>
    				<div className="col  offset-s3">
    					<img  src={require('../../img_src/account.png')}/>
    				</div>
    			</Row>
    			);
    	} else {
    		return (
    			<Row>
    				<div className="col s12 m4 offset-m3">
    					<MyCarousel data={this.state.PicsURL}/>
    				</div>
    			</Row>
    			);
    	}
    }

    render() {
    	return(
    		<div className="container">
    		<Row>
                <h4 className="col s3 m4 offset-s2 offset-m4">#######:</h4>
                {this.picDisplay()}
                <input 
                	style={{display: 'none'}} 
                	type="file"
                	accept="image/*"
                	onChange={this.fileHendler}
                	ref={fileInput => this.fileInput = fileInput}
                />
                <Button 
                	waves='light' 
                	className="col s8 m4 offset-s2 offset-m3"  
                	onClick={ () => this.fileInput.click()}
                	>Pick File<Icon right>send</Icon>
                </Button>
                <Input  type="email" className="validate" label="First name" value={this.state.FirstName} onChange={this.changeName}  s={12} />
                <Input  type="email" label="Last name" value={this.state.LastName} onChange={this.changeLastName} s={12} />
                <Input  type="email" label="Preferences" value={this.state.Preferences} onChange={this.changePreferences} s={12} />
                <Input  type="tel" label="Age" value={this.state.Age} onChange={this.changeAge} s={12} />
                <Input  type="email" label="City" value={this.state.City} onChange={this.changeCity} s={12} />
                <Input  type="email" label="Country" value={this.state.Country} onChange={this.changeCountry} s={12} />
                <Input  type="text" label="Adress" value={this.state.Adress} onChange={this.changeAdress} s={12} />
                <Input type="textarea" label="Biography:" s={12}/>
                <div className="col s12 ">
                	<Row>
    					<Input s={12} type='select' label='Select your Gender:' onChange={this.choseGender} defaultValue='Male'>
      						<option value='Male'>Male</option>
      						<option value='Female'>Female</option>
    					</Input>
  					</Row>
  					<Row>
    					<Input s={12} type='select' label='Select your gnder:' onChange={this.chosePrefer} defaultValue='Heterosexual'>
      						<option value='Heterosexual'>Heterosexual</option>
      						<option value='Homosexual'>Homosexual</option>
      						<option value='Bisexual'>Bisexual</option>
    					</Input>
  					</Row>
  				</div>

                <Button waves='light' className="col s8 m4 offset-s2 offset-m3"  onClick={this.prepareForm}>Submit<Icon right>send</Icon></Button>
            </Row>
    		</div>
    	);
    }
}

export default ExtendData
