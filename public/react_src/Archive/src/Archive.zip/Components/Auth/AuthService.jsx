import axios from 'axios'

export default class AuthService {
    constructor(domain) {
        this.domain = domain || 'http://localhost:8080';
        this.setToken = this.setToken.bind(this);
        this.getToken = this.getToken.bind(this);
        this.logout = this.logout.bind(this);
    }

    loggedIn() {
        const token = this.getToken();
        return token;
    }

    setToken(idToken) {
        localStorage.setItem('id_token', idToken);
    }

    getToken() {
        return localStorage.getItem('id_token');
    }

    logout() {
        localStorage.removeItem('id_token');
    }
}