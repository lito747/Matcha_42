import React from 'react'
// import axios from 'axios'

class Profile extends React.Component{
    constructor(props) {
        super(props);
        this.state = {

        }
    }



    render() {
        return (
            <div> Profile </div>
        );
    }
}

export default Profile