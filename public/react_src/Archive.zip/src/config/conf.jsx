var api_url = 'http://e1r2p12:8100'

module.exports.api_url = api_url;